# Android / Capacitor build

## Recommended phone-only method: GitHub Actions

The included GitHub Actions workflow builds the Android APK on a GitHub-hosted Linux runner. This avoids the ARM64 Termux limitation of the Android SDK/Gradle native toolchain.

### 1. Create a GitHub repository

Create an empty repository, for example `seller-image-price-helper`.

### 2. Upload the project

Upload the **contents** of this project directory to the repository root, including:

- `.github/workflows/android-apk.yml`
- `src/`
- `server/`
- `package.json`
- `capacitor.config.ts`
- `vite.config.ts`
- the TypeScript config files

Do not upload `node_modules/` or a locally generated `android/` directory.

### 3. Run the workflow from your phone

In GitHub:

`Repository -> Actions -> Build Android APK -> Run workflow`

The workflow performs:

1. Node.js 22 setup
2. Java 21 setup
3. `npm install`
4. ESLint
5. Vite production build
6. `npx cap add android`
7. `npx cap sync android`
8. Gradle `assembleDebug`
9. APK existence verification
10. APK artifact upload

### 4. Download the APK

Open the completed workflow run, scroll to **Artifacts**, and download:

`seller-image-price-helper-debug-apk`

Extract it and install `app-debug.apk` on your Android phone.

## Why the local Termux script does not build

Most Android phones are ARM64. The normal Android SDK/Gradle native build chain is not a reliable plain-Termux build environment. The app itself is mobile-ready; GitHub Actions is the supported phone-only build path in this project.

## Local desktop build

On a computer with Node.js 22 and Java 21:

```bash
npm install
npm run lint
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

The debug APK is:

`android/app/build/outputs/apk/debug/app-debug.apk`

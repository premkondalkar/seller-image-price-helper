#!/data/data/com.termux/files/usr/bin/bash
set -e

cat <<'MSG'
This Android phone is ARM64. A native Capacitor/Gradle build is not
reliably supported in plain Termux on ARM64.

Use the GitHub Actions workflow included with this project instead:
  1. Upload this project to a GitHub repository.
  2. Open Actions -> Build Android APK.
  3. Tap Run workflow.
  4. Download the seller-image-price-helper-debug-apk artifact.

The workflow runs the web build, lint, Capacitor Android generation,
Gradle APK build, and APK existence check before publishing the artifact.
MSG
